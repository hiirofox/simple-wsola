#pragma once

#define _USE_MATH_DEFINES
#include <math.h>
#include "fft.h"

class WSOLA
{
private:
	constexpr static int MaxInBufferSize = 65536;//һ��Ҫ�㹻��
	constexpr static int MaxOutBufferSize = 65536;
	constexpr static int MaxBlockSize = 4096;//���С
	constexpr static int MaxRange = 4096;//������Χ
	int blockSize = MaxBlockSize;
	int hopSize = blockSize / 2;
	int range = MaxRange;//������Χ

	float step = 1.0;//����������pitch
	float stepsum = 0;

	float window[MaxBlockSize];

	float inbuf[MaxInBufferSize];
	int pos = 0;
	float copybuf[MaxInBufferSize];
	float globalBuf[MaxInBufferSize];

	float outbuf[MaxOutBufferSize];
	int writepos = 0;//дָ��
	int readpos = 0;//��ָ��
	int GetMaxIndex1()//��������(��ͳ����)
	{
		int index = 0;
		float max = -999999;
		for (int i = 0; i < range; ++i)
		{
			float sum = 0;
			for (int j = 0; j < blockSize; ++j)
			{
				sum += copybuf[i + j] * globalBuf[j];
			}
			if (sum > max)
			{
				max = sum;
				index = i;
			}
		}
		//printf("index:%5d\t\tmax:%5.8f\n", index, max);
		return index;
	}
	constexpr static int FFTLen = 8192;
	float re1[FFTLen];
	float im1[FFTLen];
	float re2[FFTLen];
	float im2[FFTLen];
	int GetMaxIndex2()//�������أ�FFT������̫�ɹ���
	{
		for (int i = 0; i < range + blockSize; ++i)
		{
			re1[i] = copybuf[i];
			im1[i] = 0;
		}
		for (int i = range + blockSize; i < FFTLen; ++i)
		{
			re1[i] = 0;
			im1[i] = 0;
		}
		for (int i = 0; i < blockSize; ++i)
		{
			re2[i] = globalBuf[i];
			im2[i] = 0;
		}
		for (int i = blockSize; i < FFTLen; ++i)
		{
			re2[i] = 0;
			im2[i] = 0;
		}

		fft_f32(re1, im1, FFTLen, 1);
		fft_f32(re2, im2, FFTLen, 1);
		for (int i = 0; i < FFTLen; ++i)
		{
			float rev = re1[i] * re2[i] + im1[i] * im2[i];
			float imv = re1[i] * im2[i] - im1[i] * re2[i];
			re1[i] = rev;
			im1[i] = imv;
		}
		fft_f32(re1, im1, FFTLen, -1);
		int index = 0;
		float max = -999999;
		for (int i = 0; i < FFTLen; ++i)
		{
			float r = re1[i] * re1[i] + im1[i] * im1[i];
			if (r > max)
			{
				max = re1[i];
				index = i;
			}
		}
		printf("index:%5d\t\tmax:%5.2f\n", index, max);
		if (index>range)index = range;
		return index;
	}
public:
	WSOLA()
	{
		memset(inbuf, 0, sizeof(inbuf));
		memset(outbuf, 0, sizeof(outbuf));
		for (int i = 0; i < MaxBlockSize; ++i)
		{
			window[i] = 0.5 - 0.5 * cosf(2.0 * M_PI * i / MaxBlockSize);
		}
	}
	void SetTimeSkretch(float ratio)
	{
		step = ratio;
	}
	void ProcessIn(float* buf, int len)
	{
		for (int i = 0; i < len; ++i)
		{
			inbuf[pos] = buf[i];

			stepsum += step;
			if (stepsum >= hopSize)//�ø�����
			{
				stepsum -= hopSize;
				int start = MaxInBufferSize * 100 + pos - range - hopSize - blockSize;
				for (int j = 0; j < range + blockSize; ++j)
				{
					copybuf[j] = inbuf[(start + j) % MaxInBufferSize];
				}

				int index = GetMaxIndex1();//����Ŀ����������
				int start2 = start + index + hopSize;
				for (int j = 0; j < blockSize; ++j)//����Ŀ���
				{
					globalBuf[j] = inbuf[(start2 + j) % MaxInBufferSize] * window[j];
				}

				int start3 = start + index;
				for (int j = 0, k = writepos; j < blockSize; ++j)//����
				{
					outbuf[k % MaxOutBufferSize] += copybuf[j + index] * window[j];
					k++;
				}
				writepos += hopSize;

			}

			pos = (pos + 1) % MaxInBufferSize;
		}
	}
	bool PrepareOut(int len)
	{
		return writepos - readpos > len + blockSize;
	}
	void ProcessOut(float* buf, int len)
	{
		for (int i = 0; i < len; ++i)
		{
			int index = readpos % MaxOutBufferSize;
			buf[i] = outbuf[index];
			outbuf[index] = 0;
			readpos++;
		}
	}
};