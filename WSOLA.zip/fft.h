#pragma once
#define _USE_MATH_DEFINES
#include <math.h>

void fft_f32(float* are, float* aim, int n, int inv);
